﻿namespace PRJM15MVCJesusJuanDavid
{
    partial class anyadirpedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(anyadirpedido));
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.textBoxTLF = new System.Windows.Forms.TextBox();
            this.textBoxdirecc = new System.Windows.Forms.TextBox();
            this.textBoxNombre = new System.Windows.Forms.TextBox();
            this.labelNombre = new System.Windows.Forms.Label();
            this.labelDirecc = new System.Windows.Forms.Label();
            this.labelTLF = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.richTextBoxdescrip = new System.Windows.Forms.RichTextBox();
            this.buttonguardar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(224, 73);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 0;
            // 
            // textBoxTLF
            // 
            this.textBoxTLF.Location = new System.Drawing.Point(97, 254);
            this.textBoxTLF.Name = "textBoxTLF";
            this.textBoxTLF.Size = new System.Drawing.Size(100, 20);
            this.textBoxTLF.TabIndex = 2;
            // 
            // textBoxdirecc
            // 
            this.textBoxdirecc.Location = new System.Drawing.Point(100, 198);
            this.textBoxdirecc.Name = "textBoxdirecc";
            this.textBoxdirecc.Size = new System.Drawing.Size(100, 20);
            this.textBoxdirecc.TabIndex = 3;
            // 
            // textBoxNombre
            // 
            this.textBoxNombre.Location = new System.Drawing.Point(100, 142);
            this.textBoxNombre.Name = "textBoxNombre";
            this.textBoxNombre.Size = new System.Drawing.Size(100, 20);
            this.textBoxNombre.TabIndex = 4;
            // 
            // labelNombre
            // 
            this.labelNombre.AutoSize = true;
            this.labelNombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelNombre.Location = new System.Drawing.Point(10, 142);
            this.labelNombre.Name = "labelNombre";
            this.labelNombre.Size = new System.Drawing.Size(67, 16);
            this.labelNombre.TabIndex = 5;
            this.labelNombre.Text = "Nombre:";
            // 
            // labelDirecc
            // 
            this.labelDirecc.AutoSize = true;
            this.labelDirecc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDirecc.Location = new System.Drawing.Point(10, 198);
            this.labelDirecc.Name = "labelDirecc";
            this.labelDirecc.Size = new System.Drawing.Size(78, 16);
            this.labelDirecc.TabIndex = 6;
            this.labelDirecc.Text = "Dirección:";
            // 
            // labelTLF
            // 
            this.labelTLF.AutoSize = true;
            this.labelTLF.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTLF.Location = new System.Drawing.Point(10, 257);
            this.labelTLF.Name = "labelTLF";
            this.labelTLF.Size = new System.Drawing.Size(74, 16);
            this.labelTLF.TabIndex = 7;
            this.labelTLF.Text = "Teléfono:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(283, 188);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Descripción:";
            // 
            // richTextBoxdescrip
            // 
            this.richTextBoxdescrip.Location = new System.Drawing.Point(286, 207);
            this.richTextBoxdescrip.Name = "richTextBoxdescrip";
            this.richTextBoxdescrip.Size = new System.Drawing.Size(183, 66);
            this.richTextBoxdescrip.TabIndex = 9;
            this.richTextBoxdescrip.Text = "";
            // 
            // buttonguardar
            // 
            this.buttonguardar.BackColor = System.Drawing.Color.Blue;
            this.buttonguardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonguardar.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.buttonguardar.Location = new System.Drawing.Point(194, 301);
            this.buttonguardar.Name = "buttonguardar";
            this.buttonguardar.Size = new System.Drawing.Size(95, 32);
            this.buttonguardar.TabIndex = 10;
            this.buttonguardar.Text = "Guardar";
            this.buttonguardar.UseVisualStyleBackColor = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 18);
            this.label1.TabIndex = 11;
            this.label1.Text = "Nuevo pedido";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(97, 73);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 16);
            this.label2.TabIndex = 12;
            this.label2.Text = "DNI Cliente:";
            // 
            // anyadirpedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(481, 345);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonguardar);
            this.Controls.Add(this.richTextBoxdescrip);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.labelTLF);
            this.Controls.Add(this.labelDirecc);
            this.Controls.Add(this.labelNombre);
            this.Controls.Add(this.textBoxNombre);
            this.Controls.Add(this.textBoxdirecc);
            this.Controls.Add(this.textBoxTLF);
            this.Controls.Add(this.comboBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "anyadirpedido";
            this.Text = "anyadirpedido";
            this.Load += new System.EventHandler(this.anyadirpedido_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.TextBox textBoxTLF;
        public System.Windows.Forms.TextBox textBoxdirecc;
        public System.Windows.Forms.TextBox textBoxNombre;
        public System.Windows.Forms.Label labelNombre;
        public System.Windows.Forms.Label labelDirecc;
        public System.Windows.Forms.Label labelTLF;
        public System.Windows.Forms.Label label4;
        public System.Windows.Forms.RichTextBox richTextBoxdescrip;
        public System.Windows.Forms.ComboBox comboBox1;
        public System.Windows.Forms.Button buttonguardar;
        public System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label label2;
    }
}