﻿namespace PRJM15MVCJesusJuanDavid
{
    partial class AnyadirRepartidor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AnyadirRepartidor));
            this.anyadir = new System.Windows.Forms.Button();
            this.salirrep = new System.Windows.Forms.Button();
            this.repdni = new System.Windows.Forms.TextBox();
            this.zonarep = new System.Windows.Forms.TextBox();
            this.Nombrerep = new System.Windows.Forms.TextBox();
            this.DNIrep = new System.Windows.Forms.Label();
            this.zona = new System.Windows.Forms.Label();
            this.Nombre = new System.Windows.Forms.Label();
            this.dataGridViewrep = new System.Windows.Forms.DataGridView();
            this.Borrar = new System.Windows.Forms.Button();
            this.checkBoxactivo = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewrep)).BeginInit();
            this.SuspendLayout();
            // 
            // anyadir
            // 
            this.anyadir.BackColor = System.Drawing.Color.Blue;
            this.anyadir.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.anyadir.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.anyadir.Location = new System.Drawing.Point(478, 305);
            this.anyadir.Name = "anyadir";
            this.anyadir.Size = new System.Drawing.Size(73, 34);
            this.anyadir.TabIndex = 0;
            this.anyadir.Text = "Añadir";
            this.anyadir.UseVisualStyleBackColor = false;
            // 
            // salirrep
            // 
            this.salirrep.BackColor = System.Drawing.Color.Red;
            this.salirrep.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.salirrep.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.salirrep.Location = new System.Drawing.Point(12, 340);
            this.salirrep.Name = "salirrep";
            this.salirrep.Size = new System.Drawing.Size(75, 34);
            this.salirrep.TabIndex = 1;
            this.salirrep.Text = "Salir";
            this.salirrep.UseVisualStyleBackColor = false;
            // 
            // repdni
            // 
            this.repdni.Location = new System.Drawing.Point(78, 129);
            this.repdni.Name = "repdni";
            this.repdni.Size = new System.Drawing.Size(100, 20);
            this.repdni.TabIndex = 2;
            // 
            // zonarep
            // 
            this.zonarep.Location = new System.Drawing.Point(78, 179);
            this.zonarep.Name = "zonarep";
            this.zonarep.Size = new System.Drawing.Size(100, 20);
            this.zonarep.TabIndex = 3;
            // 
            // Nombrerep
            // 
            this.Nombrerep.Location = new System.Drawing.Point(78, 71);
            this.Nombrerep.Name = "Nombrerep";
            this.Nombrerep.Size = new System.Drawing.Size(100, 20);
            this.Nombrerep.TabIndex = 4;
            // 
            // DNIrep
            // 
            this.DNIrep.AutoSize = true;
            this.DNIrep.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DNIrep.Location = new System.Drawing.Point(9, 132);
            this.DNIrep.Name = "DNIrep";
            this.DNIrep.Size = new System.Drawing.Size(33, 13);
            this.DNIrep.TabIndex = 5;
            this.DNIrep.Text = "DNI:";
            // 
            // zona
            // 
            this.zona.AutoSize = true;
            this.zona.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zona.Location = new System.Drawing.Point(9, 182);
            this.zona.Name = "zona";
            this.zona.Size = new System.Drawing.Size(40, 13);
            this.zona.TabIndex = 6;
            this.zona.Text = "Zona:";
            // 
            // Nombre
            // 
            this.Nombre.AutoSize = true;
            this.Nombre.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nombre.Location = new System.Drawing.Point(9, 74);
            this.Nombre.Name = "Nombre";
            this.Nombre.Size = new System.Drawing.Size(54, 13);
            this.Nombre.TabIndex = 7;
            this.Nombre.Text = "Nombre:";
            // 
            // dataGridViewrep
            // 
            this.dataGridViewrep.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewrep.Location = new System.Drawing.Point(208, 31);
            this.dataGridViewrep.Name = "dataGridViewrep";
            this.dataGridViewrep.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewrep.Size = new System.Drawing.Size(343, 246);
            this.dataGridViewrep.TabIndex = 8;
            // 
            // Borrar
            // 
            this.Borrar.BackColor = System.Drawing.Color.Blue;
            this.Borrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Borrar.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Borrar.Location = new System.Drawing.Point(208, 305);
            this.Borrar.Name = "Borrar";
            this.Borrar.Size = new System.Drawing.Size(73, 34);
            this.Borrar.TabIndex = 9;
            this.Borrar.Text = "Borrar";
            this.Borrar.UseVisualStyleBackColor = false;
            // 
            // checkBoxactivo
            // 
            this.checkBoxactivo.AutoSize = true;
            this.checkBoxactivo.Location = new System.Drawing.Point(340, 283);
            this.checkBoxactivo.Name = "checkBoxactivo";
            this.checkBoxactivo.Size = new System.Drawing.Size(69, 17);
            this.checkBoxactivo.TabIndex = 10;
            this.checkBoxactivo.Text = "Noactivo";
            this.checkBoxactivo.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 18);
            this.label1.TabIndex = 11;
            this.label1.Text = "Nuevo repartidor";
            // 
            // AnyadirRepartidor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(587, 386);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkBoxactivo);
            this.Controls.Add(this.Borrar);
            this.Controls.Add(this.dataGridViewrep);
            this.Controls.Add(this.Nombre);
            this.Controls.Add(this.zona);
            this.Controls.Add(this.DNIrep);
            this.Controls.Add(this.Nombrerep);
            this.Controls.Add(this.zonarep);
            this.Controls.Add(this.repdni);
            this.Controls.Add(this.salirrep);
            this.Controls.Add(this.anyadir);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AnyadirRepartidor";
            this.Text = "AnyadirRepartidor";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewrep)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label DNIrep;
        private System.Windows.Forms.Label zona;
        private System.Windows.Forms.Label Nombre;
        public System.Windows.Forms.Button anyadir;
        public System.Windows.Forms.Button salirrep;
        public System.Windows.Forms.TextBox repdni;
        public System.Windows.Forms.TextBox zonarep;
        public System.Windows.Forms.TextBox Nombrerep;
        public System.Windows.Forms.DataGridView dataGridViewrep;
        public System.Windows.Forms.Button Borrar;
        public System.Windows.Forms.CheckBox checkBoxactivo;
        private System.Windows.Forms.Label label1;
    }
}